import React from 'react';
import { render, screen, fireEvent, act } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import LoginPage from '../Login';
import { BrowserRouter } from 'react-router-dom';
import { customerService } from '../apiUrls';

jest.mock('../apiUrls', () => ({
  customerService: {
    login: jest.fn(),
  },
}));

describe('Login Page', () => {
  it('renders login form correctly', () => {
    render(<BrowserRouter><LoginPage /></BrowserRouter>);
    expect(screen.getByRole('heading', { name: /Login/i })).toBeInTheDocument();
    expect(screen.getByLabelText(/Username/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Password/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Login/i })).toBeInTheDocument();
  });

});
