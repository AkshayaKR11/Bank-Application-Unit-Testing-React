import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Account from '../Account';
import { customerService } from '../apiUrls';
import { BrowserRouter } from 'react-router-dom';

jest.mock('../apiUrls', () => ({
  customerService: {
    account: jest.fn(),
  },
}));
jest.mock()

describe('Account Component', () => {
  it('renders account creation form correctly', () => {
    render(<BrowserRouter><Account /></BrowserRouter>);
    expect(screen.getByRole('heading', { name: /Account Create/i })).toBeInTheDocument();
    expect(screen.getByLabelText(/Account Type/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Create Account/i })).toBeInTheDocument();
  });

//  it('submits account creation form with valid data and navigates to customer header', async () => {
//     const mockResponse = { data: { message: 'Account created successfully' } };
//     customerService.account.mockResolvedValueOnce(mockResponse);

//     render(<BrowserRouter><Account /></BrowserRouter>);
//     userEvent.selectOptions(screen.getByLabelText(/Account Type/i), 'savings');

//     fireEvent.click(screen.getByRole('button', { name: /Create Account/i }));

//     await expect(customerService.account).toHaveBeenCalledWith({
//         account_type: 'savings',
      
//     });

//     window.alert('mockResponse');

//     expect(screen.queryByText('Account created successfully')).toBeInTheDocument();
//     expect(window.location.pathname).toBe('/customer_header');
//   });

  it('handles account creation form submission error', async () => {
    const errorMessage = 'Account creation failed';
    customerService.account.mockRejectedValueOnce(new Error(errorMessage));

    render(<BrowserRouter><Account /></BrowserRouter>);
    userEvent.selectOptions(screen.getByLabelText(/Account Type/i), 'salary');

    fireEvent.click(screen.getByRole('button', { name: /Create Account/i }));

    await waitFor(() => {
      expect(customerService.account).toHaveBeenCalled();
    });
    // expect(screen.getByText(errorMessage)).toBeInTheDocument();
  });
});
