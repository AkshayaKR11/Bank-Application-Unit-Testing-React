import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Transaction from '../Transaction';
import { customerService } from '../apiUrls';
import { BrowserRouter ,useNavigate} from 'react-router-dom';
import { showAlert } from '../Transaction';

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: jest.fn(),
  }));
jest.mock('../apiUrls');
jest.mock('../Transaction')

describe('Transaction Component', () => {
    let navigateMock;

    beforeEach(() => {
      navigateMock = jest.fn();
      useNavigate.mockReturnValue(navigateMock);
    });
    it('renders input for amount', () => {
        render(<Transaction />);
    
        const amountInput = screen.getByRole('number', { name: /Amount/i });
        expect(amountInput).toBeInTheDocument();
      });

  it('handles deposit form submission successfully', async () => {
    const mockResponse = { data: { message: 'Deposited Successfully' } };
    customerService.deposit.mockResolvedValueOnce(mockResponse);

    render(<BrowserRouter><Transaction /></BrowserRouter>);

    const amountInput = screen.getByLabel('Amount');
    const depositButton = screen.getByRole('button', { name: /Deposit/i });

    fireEvent.change(amountInput, { target: { value: '100' } });
    fireEvent.click(depositButton);

    expect(customerService.deposit).toHaveBeenCalledWith({ amount: '100' });
    expect(showAlert).toHaveBeenCalledWith('Deposited Successfully');
    expect(navigateMock).toHaveBeenCalledWith('/customer_header');
    
  });

  it('handles withdrawal form submission successfully', async () => {
    const mockResponse = { data: { message: 'Withdrew Successfully' } };
    customerService.withdraw.mockResolvedValueOnce(mockResponse);

    render(<BrowserRouter><Transaction /></BrowserRouter>);

    const amountInput = screen.getByLabelText('Amount');
    const withdrawButton = screen.getByRole('button', { name: /Withdraw/i });

    fireEvent.change(amountInput, { target: { value: '50' } });
    fireEvent.click(withdrawButton);

    expect(customerService.withdraw).toHaveBeenCalledWith({ amount: '50' });
    expect(show).toHaveBeenCalledWith('Withdrew Successfully');
  });

  it('handles error on deposit form submission', async () => {
    const errorMessage = 'Deposit failed';
    customerService.deposit.mockRejectedValueOnce({ response: { data: { message: errorMessage } } });

    render(<BrowserRouter><Transaction /></BrowserRouter>);

    const depositButton = screen.getByRole('button', { name: /Deposit/i });
    fireEvent.click(depositButton);

    expect(customerService.deposit).toHaveBeenCalled();
    expect(window.alert).toHaveBeenCalledWith(errorMessage);
  });

  it('handles error on withdrawal form submission', async () => {
    const errorMessage = 'Withdrawal failed';
    customerService.withdraw.mockRejectedValueOnce({ response: { data: { message: errorMessage } } });

    render(<BrowserRouter><Transaction /></BrowserRouter>);

    const withdrawButton = screen.getByRole('button', { name: /Withdraw/i });
    fireEvent.click(withdrawButton);

    expect(customerService.withdraw).toHaveBeenCalled();
    expect(window.alert).toHaveBeenCalledWith(errorMessage);
  });
});
