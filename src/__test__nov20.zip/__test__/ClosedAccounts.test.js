import React from 'react';
import { render, waitFor, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import ClosedAccounts from '../ClosedAccounts';
import { customerService } from '../apiUrls';

jest.mock('../apiUrls');

describe('ClosedAccounts Component', () => {
  it('displays closed account details correctly', async () => {
    const mockAccounts = {
      results: [
        {
          id: 1,
          account_number: '123456789',
          account_type: 'Savings',
          account_balance: 1000,
          joined_date: '2023-11-15',
          status: 'Closed',
        },
      ],
    };

    customerService.accountdetails.mockResolvedValueOnce({ data: mockAccounts });

    render(
      <MemoryRouter>
        <ClosedAccounts />
      </MemoryRouter>
    );

    await waitFor(() => {
      expect(customerService.accountdetails).toHaveBeenCalled();
    });

    expect(screen.findByText('Closed Account Details'));
    expect(screen.findByText('123456789'));
    expect(screen.findByText('Savings'));
    expect(screen.findByText('1000'));
    expect(screen.findByText('2023-11-15'));
    expect(screen.findByText('Closed'));
  });
  it('handles error while fetching closed accounts', async () => {
    const errorMessage = 'Error fetching closed accounts';

    customerService.accountdetails.mockRejectedValueOnce((errorMessage));
    render( <MemoryRouter>
      <ClosedAccounts />
    </MemoryRouter>);
    await waitFor(()=>{
      expect(screen.findByText(errorMessage))
    });
    expect(customerService.accountdetails).toHaveBeenCalled();
  });
});
