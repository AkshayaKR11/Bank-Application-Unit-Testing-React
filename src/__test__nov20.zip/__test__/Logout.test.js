import Logout from "../Logout";

describe('Logout function', () => {
  it('redirects to home header after logout', () => {
    Logout();
    expect(window.location.pathname).toBe('/');
  });
});
