import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import TransactionView from '../TransactionView';
import { customerService } from '../apiUrls';

jest.mock('../apiUrls');

describe('TransactionView component', () => {
  const mockTransactions = [
    {
      id: 1,
      transaction_type: 'Deposit',
      transaction_amount: 500,
      transaction_date: '2023-11-16',
    },
  ];

  beforeEach(() => {
    customerService.transaction_view.mockResolvedValueOnce({ data: { transactions: mockTransactions } });
  });

  it('renders transaction details correctly', async () => {
    render(
      <MemoryRouter>
        <TransactionView />
      </MemoryRouter>
    );

    await waitFor(() => {
      expect(customerService.transaction_view).toHaveBeenCalled();
      expect(screen.getByText('Deposit')).toBeInTheDocument();
      expect(screen.getByText('500')).toBeInTheDocument();
      expect(screen.getByText('2023-11-16')).toBeInTheDocument();
    });
  });
});
