import React from 'react';
import { render, waitFor, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import ClosedAccounts from '../ClosedAccounts';
import { customerService } from '../apiUrls';

jest.mock('../apiUrls');

describe('ClosedAccounts Component', () => {
  it('displays closed account details correctly', async () => {
    const mockAccounts = {
      results: [
        {
          id: 1,
          account_number: '123456789',
          account_type: 'Savings',
          account_balance: 1000,
          joined_date: '2023-11-15',
          status: 'Closed',
        },
      ],
    };

    customerService.accountdetails.mockResolvedValueOnce({ data: mockAccounts });

    render(
      <MemoryRouter>
        <ClosedAccounts />
      </MemoryRouter>
    );

    await waitFor(() => {
      expect(customerService.accountdetails).toHaveBeenCalled();
    });

    expect(screen.getByText('Closed Account Details')).toBeInTheDocument();
    expect(screen.getByText('123456789')).toBeInTheDocument();
    expect(screen.getByText('Savings')).toBeInTheDocument();
    expect(screen.getByText('1000')).toBeInTheDocument();
    expect(screen.getByText('2023-11-15')).toBeInTheDocument();
    expect(screen.getByText('Closed')).toBeInTheDocument();
  });
  it('handles error while fetching closed accounts', async () => {

    const alertMock=jest.spyOn(window,'alert');
    alertMock.mockImplementation(()=>{});

    const errorMessage = 'Failed to fetch closed accounts';
    customerService.accountdetails.mockRejectedValueOnce(new Error(errorMessage));

    render(
      <MemoryRouter>
        <ClosedAccounts />
      </MemoryRouter>
    );

    await waitFor(() => {
      expect(customerService.accountdetails).toHaveBeenCalled();
      expect(screen.getByText(`Error fetching Accounts:${errorMessage}`)).toBeInTheDocument();
    });
  });
});
