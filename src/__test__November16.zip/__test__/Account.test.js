import React from 'react';
import { render, screen, fireEvent, waitFor,act } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Account from '../Account';
import { customerService } from '../apiUrls';
import { MemoryRouter } from 'react-router-dom';

jest.mock('../apiUrls', () => ({
  customerService: {
    account: jest.fn(),
  },
}));
jest.mock()

describe('Account Component', () => {
  it('renders account creation form correctly', () => {
    render(<MemoryRouter><Account /></MemoryRouter>);
    expect(screen.getByRole('heading', { name: /Account Create/i })).toBeInTheDocument();
    expect(screen.getByLabelText(/Account Type/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Create Account/i })).toBeInTheDocument();
  });

 it('submits account creation form with valid data and navigates to customer header', async () => {
 
    const alertMock=jest.spyOn(window,'alert');
    alertMock.mockImplementation(()=>{});

    const mockResponse = { data: { message: 'Account created successfully' } };
    customerService.account.mockResolvedValueOnce(mockResponse);
  await act(async () => {
  render(<MemoryRouter><Account /></MemoryRouter>);
  const accountTypeLabel = await screen.findByLabelText(/Account Type/i);
  const accountTypeSelect = screen.getByRole('combobox', { name: accountTypeLabel.textContent });
  userEvent.selectOptions(accountTypeSelect, 'savings');
  fireEvent.click(screen.getByRole('button', { name: /Create Account/i }));
  });

    await waitFor(()=>{
    expect(customerService.account).toHaveBeenCalledWith({ account_type: 'savings'});
    expect(alertMock).toHaveBeenCalledWith('Account created successfully');
    alertMock.mockRestore();  
    expect(window.location.pathname).toBe('/customer_header')
  });
});

  it('handles account creation form submission error', async () => {
    const alertMock=jest.spyOn(window,'alert');
    alertMock.mockImplementation(()=>{});

    const errorMessage = 'Account creation failed';
    customerService.account.mockRejectedValueOnce(errorMessage);

    render(<MemoryRouter><Account /></MemoryRouter>);
    userEvent.selectOptions(screen.getByLabelText(/Account Type/i), 'salary');

    fireEvent.click(screen.getByRole('button', { name: /Create Account/i }));

    await waitFor(()=>{
      expect(customerService.account).toHaveBeenCalled();
      expect(alertMock).toHaveBeenCalledWith(errorMessage);
    });
  });
});

