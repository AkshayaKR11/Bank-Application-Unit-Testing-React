import React from 'react';
import { render, screen, fireEvent, act } from '@testing-library/react';
import Login from '../Login';
import { MemoryRouter } from 'react-router-dom';
import { customerService } from '../apiUrls';
import { jwtDecode } from 'jwt-decode';

jest.mock('../apiUrls', () => ({
  customerService: {
    login: jest.fn(),
  },
}));

jest.mock('jwt-decode', () => jest.fn());

describe('LoginPage component', () => {
  it('should handle user login and redirect to different headers based on user roles', async () => {
    const jwtDecode = jest.fn();
    jest.mock('jwt-decode', () => jwtDecode);
   
    const mockToken = 'sampleToken';
    const mockUser = { user_role: 'customer' };

    customerService.login.mockResolvedValueOnce({
      data: {
        access: mockToken,
      },
    });

    jwtDecode.mockReturnValueOnce(mockUser);

    render(
      <MemoryRouter>
        <Login />
      </MemoryRouter>
    );

    const usernameInput = screen.getByLabelText(/Username/i);
    const passwordInput = screen.getByLabelText(/Password/i);
    const loginButton = screen.getByRole('button', { name: /Login/i });

    fireEvent.change(usernameInput, { target: { value: 'testuser' } });
    fireEvent.change(passwordInput, { target: { value: 'testpassword' } });

    await act(async () => {
      fireEvent.click(loginButton);
    });

    expect(customerService.login).toHaveBeenCalledWith({
      username: 'testuser',
      password: 'testpassword',
    });

    expect(jwtDecode).toHaveBeenCalledWith(mockToken);

    expect(localStorage.setItem).toHaveBeenCalledWith(
      'authTokens',
      JSON.stringify(mockToken)
    );

    expect(screen.getByText('Login')).toBeInTheDocument(); 
  });
});
