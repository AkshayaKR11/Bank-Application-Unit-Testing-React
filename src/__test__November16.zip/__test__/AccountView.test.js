import React from 'react';
import { render, waitFor, screen } from '@testing-library/react';
import AccountView from '../AccountView';
import { customerService } from '../apiUrls';
import { MemoryRouter } from 'react-router-dom';

jest.mock('../apiUrls');

describe('AccountView Component', () => {
  it('renders account details correctly', async () => {
    const mockAccounts = {
      results: [
        {
          id: 1,
          account_number: '123456789',
          account_type: 'Savings',
          account_balance: 1000,
          joined_date: '2023-11-15',
          status: 'Approved',
        },
      ],
    };

    customerService.account_view.mockResolvedValueOnce({ data: mockAccounts });

    render(<MemoryRouter><AccountView /></MemoryRouter>);

    await waitFor(() => {
      expect(customerService.account_view).toHaveBeenCalled();
      expect(screen.findByText('123456789')).toBeInTheDocument();
      expect(screen.findByText('Savings')).toBeInTheDocument();
      expect(screen.findByText('1000')).toBeInTheDocument();
      expect(screen.findByText('2023-11-15')).toBeInTheDocument();
      expect(screen.findByText('Approved')).toBeInTheDocument();
    });
  });

  it('handles error while fetching accounts', async () => {
    
    const alertMock=jest.spyOn(window,'alert');
    alertMock.mockImplementation(()=>{});
    
    const errorMessage='Failed to fetch accounts';
    customerService.account_view.mockRejectedValueOnce(errorMessage);

    render(<MemoryRouter><AccountView /></MemoryRouter>);

    await waitFor(() => {
      expect(customerService.account_view).toHaveBeenCalled();
      expect(alertMock).toHaveBeenCalledWith(errorMessage);
      alert.mockRestore();
    });
  });
});
