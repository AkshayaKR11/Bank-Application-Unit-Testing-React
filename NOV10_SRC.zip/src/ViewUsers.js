import { useState ,useEffect} from "react";
import { customerService } from "./apiUrls";

const  ViewUsers=()=>{
  const [users, setUsers]=useState([]);
  useEffect(() => {
    async function fetchUsers() {
        try {
            const response = await  customerService.viewUsers();
            console.log(response.data)
               setUsers(response.data.results);
        } catch (error) {
            console.error('Error fetching Users:', error);
        }
    }

    fetchUsers();
}, []);

    return(
        <div className='table-style'>
        <h2>User Details</h2>
        <table border='1'>
          <thead>
            <tr>
              <th>User ID</th>
              <th>User Name</th>
              <th>Email</th>
              <th>User Type</th>
            </tr>
          </thead>
          <tbody>
          {users
    .filter(user => user.user_role === 'customer')
          .map(user => (
                        <tr key={user.id}>
                            <td>{user.id}</td>
                            <td>{user.username}</td>
                            <td>{user.email}</td>
                            <td>{user.user_role}</td>
                            <td><button>Update</button></td>
                        </tr>
                    ))}
               
          </tbody>
          </table>
          </div>
    );
}
export default ViewUsers;