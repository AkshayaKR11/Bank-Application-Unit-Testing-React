import React, { useState } from "react";
import { customerService } from "./apiUrls"; 
import { useNavigate } from "react-router-dom";

const Transaction = () => {
  const [amount, setAmount] = useState(0);
  const navigate = useNavigate();
  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = {
        amount: amount
    };
    console.log(typeof amount);
    console.log(data);
    try {
      const response = await customerService.deposit(data);
      console.log(response);
      navigate('/customer_header');
    } catch (error) {
      console.log(error);
    }
  };
  const withdrawButton = async (e) => {
    e.preventDefault();
    const data = {
        amount: amount
    };
    console.log(typeof amount);
    console.log(data);
    try {
      const response = await customerService.withdraw(data);
      console.log(response);
      navigate('/customer_header');
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="account-container content-view">
      <h2>Bank Account</h2>
      <div>
        <form onSubmit={handleSubmit}>
          <div className="input-container">
            <label htmlFor="amount">Amount</label>
            <input
              type="number"
              id="amount"
              name="amount"
              required
              min="1"
              step="1"
              value={amount}
              onChange={(e) =>setAmount(e.target.value)}
            />
          </div>
          <button type="submit">Deposit</button>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
          <button type="button" onClick={withdrawButton}>Withdraw</button>
          <br />
        </form>
      </div>
    </div>
  );
};

export default Transaction;
