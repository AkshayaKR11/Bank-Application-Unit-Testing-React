import { axiosPrivate } from './Interceptor';
const login = (data) => {
    return axiosPrivate.post('login/',data);
  };
  const signup=(data)=>{
    console.log(data)
    return axiosPrivate.post('user_register/',data);
  };
  const account=(data)=>{
    console.log(data)
    return axiosPrivate.post('account/creation/',data);
  };
  const accountdetails=()=>{
    return axiosPrivate.get('account/list/')
  }
  const viewUsers=()=>{
    return axiosPrivate.get('userview/')
  }
  const deposit=(data)=>{
    console.log(data)
    return axiosPrivate.post('transaction/deposit/',data)
  }
  const withdraw=(data)=>{
    console.log(data)
    return axiosPrivate.post('transaction/withdraw/',data)
  }
  const approve=(data,id)=>{
    console.log(data)
    return axiosPrivate.patch(`account/approveaccount/${id}`,data)
  }
  const customerService = {
    signup,
    login,
    account,
    accountdetails,
    viewUsers,
    deposit,
    withdraw,
    approve,
  };
  export {customerService};

