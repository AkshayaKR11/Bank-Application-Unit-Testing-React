import { useState ,useEffect} from "react";
import axios from "axios";

const  TransactionDetails=()=>{
  const [transactions, setTransactions]=useState([]);
  useEffect(() => {
    async function fetchTransactions() {
        try {
            const response = await axios.get('http://127.0.0.1:8000/transaction/transaction/'); 
            console.log(response.data)
            setTransactions(response.data.members);
        } catch (error) {
            console.error('Error fetching transactions:', error);
        }
    }

    fetchTransactions();
}, []);


    return(
        <div className='table-style'>
        <h2>Transaction Details</h2>
        <table border='1'>
          <thead>
            <tr>
              <th>id</th>
              <th>Transaction Type</th>
              <th>Amount</th>
              <th>Transaction Date</th>
            </tr>
          </thead>
          <tbody>
          {transactions.map(transaction => (
                        <tr key={transaction.id}>
                            <td>{transaction.id}</td>
                            <td>{transaction.transaction_type}</td>
                            <td>{transaction.transaction_amount}</td>
                            <td>{transaction.transaction_date}</td>
                        </tr>
                    ))}
               
          </tbody>
          </table>
          </div>

    );
}
export default TransactionDetails;