import {useRoutes} from 'react-router-dom'
import Login from './Login'
import Signup from './Signup';
import Account from './Account';
import Transaction from './Transaction';
import Header from './Header';
import ViewBankAccounts  from './ViewBankAccounts';
import ViewUsers from './ViewUsers';
import TransactionDetails from './TransactionDetails';
import CustomerDashboard from './CustomerDashboard';
import CustomerHeader from './CustomerHeader';
import Footer from './Footer';
import StaffHeader from './StaffHeader';
import ManagerHeader from './ManagerHeader';
import ViewStaff from './ViewStaff';
import PendingAccounts from './PendingAccounts';
export default function Routers(){
    let element=useRoutes([
        {
          path:"/login",element:<Login/>
      
        },{
          path:"/header",element:<Header/>
      
        },
        {
          path:"/customer_dashboard",element:<CustomerDashboard/>
      
        },
        {
          path:"/footer",element:<Footer/>
      
        },
        {
          path:"/customer_header",element:<CustomerHeader/>
        },
        {
          path:"/pending_accounts",element:<PendingAccounts/>
        },
        {
            path:"/signup",element:<Signup/>
        },
        {
          path:"/view_bank_accounts",element:<ViewBankAccounts/>
        },
        {
          path:"/transaction",element:<Transaction/>
        },
        {
          path:"/transactiondetails",element:<TransactionDetails/>
        },
        {
          path:"/view_user",element:<ViewUsers/>
        },
        {
          path:"/view_staff",element:<ViewStaff/>
        },
        {
          path:"/staff_header",element:<StaffHeader/>
        },
        {
          path:"/manager_header",element:<ManagerHeader/>
        },
        {
          path:"/account",element:<Account/>
      
        }])
        
        return (
          
            element
          );
        
  }