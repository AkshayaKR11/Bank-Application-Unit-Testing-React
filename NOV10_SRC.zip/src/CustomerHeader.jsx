import{Outlet,Link} from "react-router-dom";  
const CustomerHeader=()=>{

    return (
        
        <div className={"HeaderBackground-color"}>
          <nav>
           
                <Link to="/Account"><button>Create Account</button></Link>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                <Link to="/Transaction"><button>Make Payment</button></Link>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                <Link to="/TransactionDetails"><button>Transaction History</button></Link>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
             
          </nav>
    
          <Outlet />
          </div>
        
      )
    };
export default CustomerHeader;