function Footer() {
    return(
<div className="footer HeaderBackground-color" >
    <h1>@Innovature labs Bank Application</h1>
</div>
    );
}
export default Footer;