function CustomerDashboard()
{
    return(
        <div className="customer-dashboard">
        <header>
          <h1>Welcome, John Doe</h1>
          <button>Logout</button>
        </header>
        <div className="account-summary">
          <div className="account-balance">
            <h2>Account Balance</h2>
            <p>$5,000.00</p>
          </div>
          <div className="recent-transactions">
            <h2>Recent Transactions</h2>
            <ul>
              <li>
                <span className="transaction-type">Deposit</span>
                <span className="transaction-amount">+$1,000.00</span>
              </li>
              <li>
                <span className="transaction-type">Withdrawal</span>
                <span className="transaction-amount">-$500.00</span>
              </li>
              <li>
                <span className="transaction-type">Transfer</span>
                <span className="transaction-amount">-$200.00</span>
              </li>
              {/* Add more transaction items */}
            </ul>
          </div>
        </div>
        <div className="transaction-actions">
          <h2>Perform a Transaction</h2>
          <button>Make a Deposit</button>
          <button>Make a Withdrawal</button>
          <button>Make a Transfer</button>
        </div>
      </div>
    );
  };
  
  export default CustomerDashboard;
    
