import React, { useState} from 'react';
import { useNavigate } from 'react-router-dom';
import { jwtDecode } from 'jwt-decode'
import { customerService } from './apiUrls';

const LoginPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    const data={username: username,
      password: password,}
    try {
      const response = await customerService.login(data);
      console.log(response)
      const token=response.data.access 
      console.log(token)
      localStorage.setItem("authTokens",JSON.stringify(token)) 
      const decode=jwtDecode(token)   
      console.log(decode.user_role)
      if (decode.user_role === 'customer')
      {
        navigate('/customer_header');
      } 
      else if (decode.user_role === 'staff')
      {
        navigate('/staff_header');
      }
      else if (decode.user_role === 'manager') 
      {
        navigate('/manager_header');
    
      } 
    }
    catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="login-container content-view">
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <div className="input-container">
          <label htmlFor="username">Username</label>
          <input
            type="text"
            id="username"
            name="username"
            required
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div className="input-container">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button type="submit">Login</button> &nbsp;
        <button>Signup?</button>
      </form>
    </div>
  );
};

export default LoginPage;
