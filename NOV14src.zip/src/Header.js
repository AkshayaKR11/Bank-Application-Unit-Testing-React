import{Outlet,Link} from "react-router-dom";

const Header=()=>{

    return (
        <>
          <nav>
           
                <Link to="/Signup">Sign Up</Link>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                <Link to="/Transaction">Make Payment</Link>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                <Link to="/Account">Add  Account</Link>
             
          </nav>
    
          <Outlet />
        </>
      )
    };
export default Header;