// import { useEffect } from "react";
// import { useNavigate } from "react-router-dom";

// const Logout=()=>{

//     useEffect(()=>{
//         localStorage.clear();
//         Navigate('/login')
//     })
//     return(


//     );
// }